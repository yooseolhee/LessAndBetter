import {FaRegThumbsUp} from "react-icons/fa";
import Card from "../layout/Card";

export default function PopularPost() {
  return (
    <section>
      <Card title="오늘의 인기글">
        오늘의 인기글
        <FaRegThumbsUp /> 00
      </Card>
    </section>
  );
}
