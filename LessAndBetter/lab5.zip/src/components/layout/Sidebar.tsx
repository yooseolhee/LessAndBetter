import { onAuthStateChanged, signOut, type User } from "firebase/auth";
import {
  Home,
  Dumbbell,
  Users,
  Settings,
  Timer,
  Menu,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { auth } from "../../firebase";

const menus = [
  { name: "홈", icon: Home, path: "/home" },
  { name: "운동", icon: Dumbbell, path: "/training" },
  { name: "커뮤니티", icon: Users, path: "/community" },
  { name: "인터벌 타이머", icon: Timer, path: "/timer" },
  { name: "설정", icon: Settings, path: "/settings" },
];

export default function Sidebar() {
  const [user, setUser] = useState<User | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });
    return unsubscribe;
  }, []);

  return (
    <>
      {/* 📱 모바일 햄버거 (md 이상에서는 아예 안 보임) */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed top-16 left-4 z-50 p-2 rounded-xl bg-white shadow md:hidden"
      >
        <Menu className="w-6 h-6 text-green-600" />
      </button>

      {/* 📱 모바일 오버레이 */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/30 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* 사이드바 wrapper (항상 렌더) */}
      <div className="fixed top-0 left-0 z-50 h-screen flex items-center md:group">
        {/* 💻 노트북 hover 감지 영역 */}
        <div className="absolute top-0 left-0 h-full w-20 hidden md:block" />

        {/* ✅ 사이드바 */}
        <aside
          className={[
            // 공통 스타일
            "h-[80dvh]",
            "w-[22vw]",
            "min-w-[240px]",
            "max-w-[360px]",
            "bg-white",
            "rounded-r-2xl",
            "shadow-2xl",
            "p-3",
            "flex",
            "flex-col",
            "gap-3",
            "transform",
            "transition-transform",
            "duration-300",
            "ease-out",

            // 📱 모바일 기본: 닫힘
            "md:translate-x-0",
            isOpen ? "translate-x-0" : "-translate-x-full",

            // 💻 노트북: hover 제어
            "md:-translate-x-full",
            "md:group-hover:translate-x-0",
          ].join(" ")}
        >
          {/* 📱 모바일 닫기 버튼 */}
          <button
            onClick={() => setIsOpen(false)}
            className="md:hidden self-end p-2"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>

          {/* 프로필 */}
          <div className="p-3 bg-gray-50 rounded-xl">
            <div className="w-20 h-20 mb-3 rounded-full overflow-hidden bg-gray-200">
              {user?.photoURL ? (
                <img
                  src={user.photoURL}
                  alt="profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400 text-sm">
                  NO IMAGE
                </div>
              )}
            </div>

            {!user ? (
              <div className="flex flex-col gap-2">
                <span className="text-sm font-semibold text-gray-600">
                  로그인이 필요합니다.
                </span>
                <button
                  onClick={() => navigate("/login")}
                  className="mt-2 px-4 py-2 text-sm rounded-xl bg-green-600 text-white"
                >
                  로그인
                </button>
                <button
                  onClick={() => navigate("/signup")}
                  className="px-4 py-2 text-sm rounded-xl border border-gray-300"
                >
                  회원가입
                </button>
              </div>
            ) : (
              <>
                <p className="text-gray-700 text-sm">{user.email}</p>
                <button
                  onClick={() => signOut(auth)}
                  className="text-xs mt-3 px-2 py-1 rounded-full border border-gray-300"
                >
                  로그아웃
                </button>
              </>
            )}
          </div>

          {/* 메뉴 */}
          <nav className="flex flex-col gap-2">
            {menus.map((m) => (
              <NavLink
                key={m.name}
                to={m.path}
                onClick={() => setIsOpen(false)}
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-gradient-to-r from-green-100 to-white"
              >
                <m.icon className="w-5 h-5 text-green-500" />
                <span className="text-xs">{m.name}</span>
              </NavLink>
            ))}
          </nav>
        </aside>
      </div>
    </>
  );
}
