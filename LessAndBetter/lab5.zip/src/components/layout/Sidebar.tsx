import { onAuthStateChanged, signOut, type User } from "firebase/auth";
import { Home, Dumbbell, Utensils, Users, Settings } from "lucide-react";
import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { auth } from "../../firebase";

const menus = [
  { name: "홈", icon: Home, path:'/home' },
  { name: "운동", icon: Dumbbell , path:'/training'},
  { name: "커뮤니티", icon: Users , path:'/community'},
  { name: "설정", icon: Settings, path:'/settings' },
];

export default function Sidebar() {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });
    return unsubscribe;
  }, []);

  return (
   <aside
  className="
    h-[100dvh]
    w-[22vw]
    min-w-[240px]
    max-w-[360px]
    bg-white
    rounded-2xl
    shadow-2xl
    p-5
    flex
    flex-col
    gap-6
  "
>
      {/* 프로필 */}
      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-blue-400" />
        <div>
          <p className="text-sm font-semibold">
            {!user ? (
                      <span>로그인을 해주세요.</span>
                    ) : (
                      <>
                        <span className="text-gray-700 text-sm">
                          {user.email}
                        </span>
                        <button
                          onClick={() => signOut(auth)}
                          className="m-1 px-3 py-1 rounded-full border border-gray-300 hover:bg-gray-100"
                        >
                          로그아웃
                        </button>
                      </>
                    )}
          </p>
        </div>
      </div>

      {/* 메뉴 */}
      <nav className="flex flex-col gap-2">
        {menus.map((m) => (
          <NavLink
            key={m.name}
            to={m.path}
            className="flex items-center gap-3 p-8 rounded-xl hover:bg-gradient-to-r from-green-100 to-white-400 transition"
          >
            <m.icon className="w-5 h-5 text-green-500" />
            <span className="text-sm">{m.name}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
