
import TodayWorkout from "../components/home/TodayWorkout";
import TodayTopPost from "../features/home/TodayTopPost";

export default function Home() {
  return (
      <div className="grid grid-cols-3 gap-12">
        <TodayWorkout />
        <TodayTopPost />
      </div>
  );
}
