import { signOut } from "firebase/auth";
import Layout from "../components/layout/Layout";
import AccountDangerZone from "../components/settings/AccountDangerZone";
import { auth } from "../firebase";

export default function Settings() {

  return (
    <div>
      <h1 className="text-3xl font-bold mb-10">Settings</h1>

      <AccountDangerZone />

  
    </div>
  );
}
