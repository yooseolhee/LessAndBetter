import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { SortType, Post } from "./types";
import { fetchPosts } from "./api";
import CommunityToolbar from "./CommunityToolbar";
import PostCard from "./PostCard";

export default function CommunityPage() {
  const nav = useNavigate();
  const [sort, setSort] = useState<SortType>("latest");
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetchPosts(sort)
      .then(setPosts)
      .finally(() => setLoading(false));
  }, [sort]);

  return (
    <>
      <div>
      <h1 className="text-3xl font-bold mb-2">
        COMMUNITY
      </h1>
      <p className="text-xl">
        여러분의 일상을 공유해주세요!
      </p>
    </div>

    <div className="py-8">
      <CommunityToolbar
        sort={sort}
        onChangeSort={setSort}
        onWrite={() => nav("/community/write")}
      />

      {loading ? (
        <p className="text-gray-500">불러오는 중...</p>
      ) : (
        <div className="grid grid-cols-3 gap-10 items-stretch">
          {posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onClick={() => nav(`/community/${post.id}`)}
            />
          ))}
        </div>
      )}
    </div>
    </>
  );
}
