import {
  addDoc,
  collection,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  doc,
  increment,
  runTransaction,
  getDoc,
} from "firebase/firestore";
import { auth, db } from "../../firebase";
import type { SortType, Post } from "./types";

/* 게시글 작성 */
export async function createPost(title: string, content: string) {
  const user = auth.currentUser;
  if (!user) throw new Error("로그인 필요");

  await addDoc(collection(db, "posts"), {
    title,
    content,
    authorUid: user.uid,
    authorName: user.displayName ?? "익명",
    createdAt: serverTimestamp(),
    likeCount: 0,
    commentCount: 0,
  });
}

/* 게시글 목록 불러오기 */
export async function fetchPosts(sort: SortType): Promise<Post[]> {
  let q;

  if (sort === "latest") {
    q = query(collection(db, "posts"), orderBy("createdAt", "desc"));
  } else if (sort === "popular") {
    q = query(collection(db, "posts"), orderBy("likeCount", "desc"));
  } else {
    q = query(collection(db, "posts"), orderBy("commentCount", "desc"));
  }

  const snapshot = await getDocs(q);

  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...(doc.data() as Omit<Post, "id">),
  }));
}


/* 단일 게시글 조회 */
export async function fetchPostById(postId: string): Promise<Post | null> {
  const ref = doc(db, "posts", postId);
  const snap = await getDoc(ref);

  if (!snap.exists()) return null;

  return {
    id: snap.id,
    ...(snap.data() as Omit<Post, "id">),
  };
}

/* 좋아요 토글 (트랜잭션) */
export async function toggleLike(postId: string) {
  const user = auth.currentUser;
  if (!user) throw new Error("로그인 필요");

  const postRef = doc(db, "posts", postId);

  await runTransaction(db, async (tx) => {
    const snap = await tx.get(postRef);
    if (!snap.exists()) return;

    const data = snap.data();
    const likedBy = data.likedBy ?? {};
    const alreadyLiked = !!likedBy[user.uid];

    tx.update(postRef, {
      likeCount: increment(alreadyLiked ? -1 : 1),
      [`likedBy.${user.uid}`]: alreadyLiked ? false : true,
    });
  });
}

/* 댓글 목록 조회 */
export async function fetchComments(postId: string) {
  const q = query(
    collection(db, "posts", postId, "comments"),
    orderBy("createdAt", "desc")
  );

  const snap = await getDocs(q);

  return snap.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  }));
}

/* 댓글 작성 */
export async function createComment(postId: string, content: string) {
  const user = auth.currentUser;
  if (!user) throw new Error("로그인 필요");

  const postRef = doc(db, "posts", postId);

  await addDoc(collection(db, "posts", postId, "comments"), {
    content,
    authorUid: user.uid,
    authorName: user.displayName ?? "익명",
    createdAt: serverTimestamp(),
  });

  await runTransaction(db, async (tx) => {
    tx.update(postRef, {
      commentCount: increment(1),
    });
  });
}