import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPost } from "./api";

export default function CommunityWritePage() {
  const nav = useNavigate();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async () => {
    if (!title.trim() || !content.trim()) return;

    try {
      setLoading(true);
      await createPost(title, content);
      nav("/community");
    } catch (e) {
      alert("게시글 작성 실패");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="px-10 py-8 max-w-4xl">
      <h1 className="text-2xl font-bold mb-6">게시글 작성</h1>

      <input
        className="w-full mb-4 px-4 py-2 border rounded-xl"
        placeholder="제목"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      <textarea
        className="w-full min-h-[240px] px-4 py-3 border rounded-xl"
        placeholder="내용"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      />

      <div className="flex justify-end mt-4 gap-2">
        <button onClick={() => nav("/community")}>취소</button>
        <button
          onClick={onSubmit}
          disabled={loading}
          className="bg-indigo-600 text-white px-4 py-2 rounded-xl"
        >
          등록
        </button>
      </div>
    </div>
  );
}
