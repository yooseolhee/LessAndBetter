import type { Timestamp } from "firebase/firestore";

export type SortType = "latest" | "popular" | "comment";

export type Post = {
  id: string;
  title: string;
  content: string;
  authorUid: string;
  authorName: string;
  createdAt: Timestamp;
  likeCount: number;
  commentCount: number;
};
